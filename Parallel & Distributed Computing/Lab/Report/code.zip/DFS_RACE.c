#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <stdbool.h>

#define NUM_THREADS 4

typedef struct
{
    int **adjMatrix;
    int numVertices;
} Graph;

Graph *createGraph(int vertices)
{
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjMatrix = (int **)malloc(vertices * sizeof(int *));
    for (int i = 0; i < vertices; i++)
    {
        graph->adjMatrix[i] = (int *)malloc(vertices * sizeof(int));
        for (int j = 0; j < vertices; j++)
        {
            graph->adjMatrix[i][j] = 0;
        }
    }
    return graph;
}

void addEdge(Graph *graph, int u, int v)
{
    graph->adjMatrix[u][v] = 1;
    graph->adjMatrix[v][u] = 1;
}

void dfs(Graph *graph, int startVertex)
{
    bool *visited = (bool *)malloc(graph->numVertices * sizeof(bool));
    for (int i = 0; i < graph->numVertices; i++)
    {
        visited[i] = false;
    }

    int *stack = (int *)malloc(graph->numVertices * sizeof(int));
    int top = -1;

    stack[++top] = startVertex;
    visited[startVertex] = true;

#pragma omp parallel num_threads(NUM_THREADS)
    {
        while (top >= 0)
        {
            int currentVertex;

#pragma omp critical
            {
                if (top >= 0)
                {
                    currentVertex = stack[top--];
                    printf("Visiting: %d\n", currentVertex);
                }
            }

#pragma omp for
            for (int i = 0; i < graph->numVertices; i++)
            {
                if (graph->adjMatrix[currentVertex][i] && !visited[i])
                {
                    visited[i] = true;
                    stack[++top] = i;
                }
            }
        }
    }

    free(visited);
    free(stack);
}

int main()
{
    Graph *graph = createGraph(6);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 5);

    dfs(graph, 0);

    for (int i = 0; i < graph->numVertices; i++)
    {
        free(graph->adjMatrix[i]);
    }
    free(graph->adjMatrix);
    free(graph);

    return 0;
}
