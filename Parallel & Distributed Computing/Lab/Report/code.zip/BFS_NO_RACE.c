#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <stdbool.h>

#define NUM_THREADS 4

typedef struct
{
    int **adjMatrix;
    int numVertices;
} Graph;

Graph *createGraph(int vertices)
{
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjMatrix = (int **)malloc(vertices * sizeof(int *));
    for (int i = 0; i < vertices; i++)
    {
        graph->adjMatrix[i] = (int *)malloc(vertices * sizeof(int));
        for (int j = 0; j < vertices; j++)
        {
            graph->adjMatrix[i][j] = 0;
        }
    }
    return graph;
}

void addEdge(Graph *graph, int u, int v)
{
    graph->adjMatrix[u][v] = 1;
    graph->adjMatrix[v][u] = 1;
}

void bfs(Graph *graph, int startVertex)
{
    bool *visited = (bool *)malloc(graph->numVertices * sizeof(bool));
    for (int i = 0; i < graph->numVertices; i++)
    {
        visited[i] = false;
    }

    int *queue = (int *)malloc(graph->numVertices * sizeof(int));
    int front = 0, rear = 0;

    visited[startVertex] = true;
    queue[rear++] = startVertex;

    omp_lock_t lock;
    omp_init_lock(&lock);

#pragma omp parallel num_threads(NUM_THREADS)
    {
        while (true)
        {
            int currentVertex = -1;

            omp_set_lock(&lock);
            if (front < rear)
            {
                currentVertex = queue[front++];
            }
            omp_unset_lock(&lock);

            if (currentVertex == -1)
            {
                break;
            }

#pragma omp critical
            {
                printf("Visiting: %d\n", currentVertex);
            }

#pragma omp parallel for
            for (int i = 0; i < graph->numVertices; i++)
            {
                if (graph->adjMatrix[currentVertex][i])
                {
                    omp_set_lock(&lock);
                    if (!visited[i])
                    {
                        visited[i] = true;
                        queue[rear++] = i;
                    }
                    omp_unset_lock(&lock);
                }
            }

            // Ensure all threads complete before checking the queue again
#pragma omp barrier
        }
    }

    omp_destroy_lock(&lock);
    free(visited);
    free(queue);
}

int main()
{
    Graph *graph = createGraph(6);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 5);

    bfs(graph, 0);

    for (int i = 0; i < graph->numVertices; i++)
    {
        free(graph->adjMatrix[i]);
    }
    free(graph->adjMatrix);
    free(graph);

    return 0;
}
