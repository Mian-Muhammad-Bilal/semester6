#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <stdbool.h>

#define NUM_THREADS 4

typedef struct
{
    int **adjMatrix;
    int numVertices;
} Graph;

Graph *createGraph(int vertices)
{
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjMatrix = (int **)malloc(vertices * sizeof(int *));
    for (int i = 0; i < vertices; i++)
    {
        graph->adjMatrix[i] = (int *)malloc(vertices * sizeof(int));
        for (int j = 0; j < vertices; j++)
        {
            graph->adjMatrix[i][j] = 0;
        }
    }
    return graph;
}

void addEdge(Graph *graph, int u, int v)
{
    graph->adjMatrix[u][v] = 1;
    graph->adjMatrix[v][u] = 1;
}

void parallelDFSUtil(Graph *graph, int startVertex, bool *visited, omp_lock_t *lock)
{
#pragma omp task
    {
        omp_set_lock(lock);
        if (!visited[startVertex])
        {
            visited[startVertex] = true;
            printf("Visiting: %d\n", startVertex);
        }
        omp_unset_lock(lock);

        for (int i = 0; i < graph->numVertices; i++)
        {
            if (graph->adjMatrix[startVertex][i])
            {
                omp_set_lock(lock);
                if (!visited[i])
                {
                    omp_unset_lock(lock);
                    parallelDFSUtil(graph, i, visited, lock);
                }
                else
                {
                    omp_unset_lock(lock);
                }
            }
        }
    }
}

void parallelDFS(Graph *graph, int startVertex)
{
    bool *visited = (bool *)malloc(graph->numVertices * sizeof(bool));
    for (int i = 0; i < graph->numVertices; i++)
    {
        visited[i] = false;
    }

    omp_lock_t lock;
    omp_init_lock(&lock);

#pragma omp parallel num_threads(NUM_THREADS)
    {
#pragma omp single
        {
            parallelDFSUtil(graph, startVertex, visited, &lock);
        }
    }

    omp_destroy_lock(&lock);
    free(visited);
}

int main()
{
    Graph *graph = createGraph(6);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 5);

    parallelDFS(graph, 0);

    for (int i = 0; i < graph->numVertices; i++)
    {
        free(graph->adjMatrix[i]);
    }
    free(graph->adjMatrix);
    free(graph);
    return 0;
}
