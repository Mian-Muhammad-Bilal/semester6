#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <stdbool.h>

#define NUM_THREADS 4

typedef struct
{
    int **adjMatrix;
    int numVertices;
} Graph;

Graph *createGraph(int vertices)
{
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    graph->numVertices = vertices;
    graph->adjMatrix = (int **)malloc(vertices * sizeof(int *));
    for (int i = 0; i < vertices; i++)
    {
        graph->adjMatrix[i] = (int *)malloc(vertices * sizeof(int));
        for (int j = 0; j < vertices; j++)
        {
            graph->adjMatrix[i][j] = 0;
        }
    }
    return graph;
}

void addEdge(Graph *graph, int u, int v)
{
    graph->adjMatrix[u][v] = 1;
    graph->adjMatrix[v][u] = 1;
}

void bfs(Graph *graph, int startVertex)
{
    bool *visited = (bool *)malloc(graph->numVertices * sizeof(bool));
    for (int i = 0; i < graph->numVertices; i++)
    {
        visited[i] = false;
    }

    int *queue = (int *)malloc(graph->numVertices * sizeof(int));
    int front = 0, rear = 0;

    visited[startVertex] = true;
    queue[rear++] = startVertex;

#pragma omp parallel num_threads(NUM_THREADS)
    {
        while (front != rear)
        {
            int currentVertex;

#pragma omp critical
            {
                if (front != rear)
                {
                    currentVertex = queue[front++];
                    printf("Visiting: %d\n", currentVertex);
                }
            }

#pragma omp for
            for (int i = 0; i < graph->numVertices; i++)
            {
                if (graph->adjMatrix[currentVertex][i] && !visited[i])
                {
                    visited[i] = true;
                    queue[rear++] = i;
                }
            }
        }
    }

    free(visited);
    free(queue);
}

int main()
{
    Graph *graph = createGraph(6);
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 5);

    bfs(graph, 0);

    for (int i = 0; i < graph->numVertices; i++)
    {
        free(graph->adjMatrix[i]);
    }
    free(graph->adjMatrix);
    free(graph);

    return 0;
}
